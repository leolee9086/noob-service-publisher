import { 生成文档树 } from "./filtree/index.js";
await 生成文档树()
